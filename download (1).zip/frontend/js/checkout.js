document.getElementById('checkout-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const phone = document.getElementById('phone').value;
    const deliveryType = document.getElementById('delivery-type').value;

    const cart = getCart();

    const order = {
        customer: { name, address, phone },
        items: cart,
        deliveryType
    };

    const createdOrder = await createOrder(order);

    // Clear cart
    saveCart([]);

    // Redirect to success page
    window.location.href = `success.html?orderId=${createdOrder._id}`;
});
