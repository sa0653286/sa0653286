document.addEventListener('DOMContentLoaded', () => {
    loadProductDetails();
});

async function loadProductDetails() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    const product = await getProduct(productId);

    const productDetailsContainer = document.getElementById('product-details');

    if (productDetailsContainer) {
        productDetailsContainer.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <div>
                <h1>${product.name}</h1>
                <p>${product.description}</p>
                <p>Price: ${product.price}</p>
                <button onclick="addToCart('${product._id}', '${product.name}', ${product.price}, '${product.image}')">Add to Cart</button>
            </div>
        `;
    }
}
