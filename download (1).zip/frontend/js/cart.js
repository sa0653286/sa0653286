document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
    displayCartItems();
});

function getCart() {
    return JSON.parse(localStorage.getItem('cart')) || [];
}

function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
}

function addToCart(productId, name, price, image) {
    const cart = getCart();
    const existingItem = cart.find(item => item.productId === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ productId, name, price, image, quantity: 1 });
    }

    saveCart(cart);
}

function updateCartCount() {
    const cart = getCart();
    const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    document.getElementById('cart-count').textContent = cartCount;
}

function displayCartItems() {
    const cartItemsContainer = document.getElementById('cart-items');
    if (!cartItemsContainer) return;

    const cart = getCart();
    cartItemsContainer.innerHTML = '';

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }

    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <img src="${item.image}" alt="${item.name}">
                <div>
                    <h3>${item.name}</h3>
                    <p>Price: ${item.price}</p>
                </div>
            </div>
            <div class="quantity-controls">
                <button onclick="decrementQuantity('${item.productId}')">-</button>
                <span>${item.quantity}</span>
                <button onclick="incrementQuantity('${item.productId}')">+</button>
                <button onclick="removeFromCart('${item.productId}')">Remove</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });

    updateCartTotal();
}

function updateCartTotal() {
    const cart = getCart();
    const total = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    document.getElementById('cart-total').textContent = total.toFixed(2);
}

function incrementQuantity(productId) {
    const cart = getCart();
    const item = cart.find(item => item.productId === productId);
    if (item) {
        item.quantity++;
        saveCart(cart);
        displayCartItems();
    }
}

function decrementQuantity(productId) {
    const cart = getCart();
    const item = cart.find(item => item.productId === productId);
    if (item && item.quantity > 1) {
        item.quantity--;
        saveCart(cart);
        displayCartItems();
    }
}

function removeFromCart(productId) {
    let cart = getCart();
    cart = cart.filter(item => item.productId !== productId);
    saveCart(cart);
    displayCartItems();
}
