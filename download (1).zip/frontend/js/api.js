const API_URL = 'http://localhost:5000';

async function getProducts() {
    const response = await fetch(`${API_URL}/api/products`);
    const data = await response.json();
    return data;
}

async function getProduct(id) {
    const response = await fetch(`${API_URL}/api/products/${id}`);
    const data = await response.json();
    return data;
}

async function createOrder(order) {
    const response = await fetch(`${API_URL}/api/orders`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(order)
    });
    const data = await response.json();
    return data;
}

async function getOrder(id) {
    const response = await fetch(`${API_URL}/api/orders/${id}`);
    const data = await response.json();
    return data;
}
