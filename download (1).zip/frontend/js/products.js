document.addEventListener('DOMContentLoaded', () => {
    loadAllProducts();
});

async function loadAllProducts() {
    const products = await getProducts();
    const productsGrid = document.getElementById('products-grid');

    if (productsGrid) {
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.innerHTML = `
                <a href="product-details.html?id=${product._id}">
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p>Price: ${product.price}</p>
                </a>
                <button onclick="addToCart('${product._id}', '${product.name}', ${product.price}, '${product.image}')">Add to Cart</button>
            `;
            productsGrid.appendChild(productCard);
        });
    }
}
