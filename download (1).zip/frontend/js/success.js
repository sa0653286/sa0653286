document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');

    const order = await getOrder(orderId);

    const orderSummaryContainer = document.getElementById('order-summary');
    const whatsappConfirmLink = document.getElementById('whatsapp-confirm');

    if (orderSummaryContainer) {
        let itemsHtml = order.items.map(item => `<li>${item.name} (x${item.quantity})</li>`).join('');

        orderSummaryContainer.innerHTML = `
            <h2>Order Summary</h2>
            <p><strong>Order ID:</strong> ${order._id}</p>
            <p><strong>Customer:</strong> ${order.customer.name}</p>
            <p><strong>Total:</strong> ${order.total}</p>
            <ul>${itemsHtml}</ul>
        `;

        // Create WhatsApp message
        const message = `Hello, I just placed an order with ID: ${order._id}. Please confirm.`;
        whatsappConfirmLink.href = `https://wa.me/8638993766?text=${encodeURIComponent(message)}`;
    }
});
