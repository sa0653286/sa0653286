document.addEventListener('DOMContentLoaded', () => {
    loadFeaturedProducts();
});

async function loadFeaturedProducts() {
    const products = await getProducts();
    const featuredProductsGrid = document.getElementById('featured-products-grid');

    if (featuredProductsGrid) {
        // Assuming the first 4 products are featured
        products.slice(0, 4).forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.innerHTML = `
                <a href="product-details.html?id=${product._id}">
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p>Price: ${product.price}</p>
                </a>
                <button onclick="addToCart('${product._id}', '${product.name}', ${product.price}, '${product.image}')">Add to Cart</button>
            `;
            featuredProductsGrid.appendChild(productCard);
        });
    }
}
